﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
// added...
using $safeprojectname$.Models;

namespace $safeprojectname$.Controllers
{
    public class Manager
    {
        // Data store
        private ApplicationDbContext ds = new ApplicationDbContext();

        public Manager()
        {
            // Default constructor, if needed
        }

        // ########################################

        // Get-all, get-all-filtered, get-one, add-new, edit-existing, delete-one
        // With associated objects if necessary

    }
}
